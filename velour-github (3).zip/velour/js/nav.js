/* ===== VELOUR — Shared Nav Builder ===== */
import { t, getLang, setLang } from './i18n.js';

export function buildNav(activePage) {
  const lang = getLang();
  return `
  <nav id="main-nav">
    <a class="logo" href="${activePage === 'home' ? 'index.html' : '../index.html'}">
      VELOUR<span class="logo-sub">Car Rental</span>
    </a>
    <div class="nav-links">
      <a href="${activePage === 'home' ? 'index.html' : '../index.html'}">${t('nav_home')}</a>
      <a href="${activePage === 'home' ? 'pages/browse.html' : 'browse.html'}">${t('nav_browse')}</a>
      <a href="${activePage === 'home' ? 'pages/how.html' : 'how.html'}">${t('nav_how')}</a>
      <div class="lang-switcher">
        <button class="lang-btn ${lang === 'uz' ? 'active' : ''}" onclick="switchLang('uz')">UZ</button>
        <span style="color:rgba(250,247,242,0.3);">|</span>
        <button class="lang-btn ${lang === 'ru' ? 'active' : ''}" onclick="switchLang('ru')">RU</button>
      </div>
    </div>
  </nav>`;
}

export function switchLangAndReload(l) {
  setLang(l);
  location.reload();
}
